<?php
    include '../core/dbe.inc.php';
    include '../core/core.inc.php';
    include '../core/notification_manager.php';
    // session_start(); 
    // checkManager(); 
?>

<?php
    $result = null;

    if (isset($_POST['city_id']) && isset($_POST['category_id'])) {
        $city_id = $_POST['city_id'];
        $location = $_POST['location'];
        $category_id = $_POST['category_id'];
        $auction_title = $_POST['auction_title'];
        $auction_desc = $_POST['auction_desc'];
        $condition = $_POST['condition'];
        $product_type = $_POST['product_type'];
        $starting_price = $_POST['starting_price'];
        $reserve_price = $_POST['reserve_price'];
        $keyword = $_POST['keyword'];
        $starting_date = $_POST['starting_date'];
        $ending_date = $_POST['ending_date'];
        $com_id = $_POST['com_id'];

        $filesname = array();
        $fileErr = "";

        $updir = '../public/uploads/auction/';

        foreach ($_FILES['file']['name'] as $key => $filename) {
            $filename = $_FILES['file']['name'][$key];
            $filesize = $_FILES['file']['size'][$key];
            $filetmp = $_FILES['file']['tmp_name'][$key];
            
            $fext = (explode('.', $filename));
            $fileext = end($fext);

            $expensions = array("jpeg", "jpg", "png");

            if (in_array($fileext, $expensions) === false) {
                $fileErr = "Extension not allowed, Please Choose a JPEG or PNG file.";
            }

            if ($filesize > 2097152) {
                $fileErr = 'File size must be less than 2 MB';
            }

            if (empty($fileErr) == true) {
                $fname = rand(100000, 999999) . "" . date("his") . "." . $fileext;
                array_push($filesname, $fname);
                
                $filepath = $updir . $fname;
                move_uploaded_file($filetmp, $filepath);
            }
        }


        if (count($filesname) > 0 && empty($fileErr)) {
            $query = "INSERT INTO `auction` (`city_id`, `location`, `category_id`, `keyword`, `auction_title`, `auction_desc`, `starting_date`, `ending_date`, `starting_price`, `reserve_price`, `condition`, `product_type`, `com_id`)
                VALUES ('$city_id', '$location', '$category_id', '$keyword', '$auction_title', '$auction_desc', '$starting_date', '$ending_date', '$starting_price', '$reserve_price', '$condition', '$product_type', '$com_id')";
            $data = query($query);
            $post_id = insertID();

            foreach ($filesname as $file) {
                $file = "/public/uploads/auction/" . $file;
                $query = "INSERT INTO `auction_image` (`auction_id`, `image`) VALUES ('$post_id', '$file') ";
                $data = query($query);
            }

            if ($post_id != 0) {
                send_notification($post_id, $auction_title, $starting_price, $location);
            }

            $result = array([
                "status" => 1,
                "data" => $post_id
            ]);
        } 
        else {

            $result = array([
                "status" => -1,
                "data" => $fileErr
            ]);

        }

    } 
    else {
        $result = array([
            "status" => 0,
            "data" => "Something went wrong"
        ]);
    }
    echo json_encode($result);
?>